<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\NameController;
use App\Http\Controllers\OperationsController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
 
// Exercício 1 a)
Route::get('oi/{name}/{lastName}', [NameController::class, 'index']);

// Exercício 1 b)
Route::get('soma/{num1}/{num2}', [OperationsController::class, 'sum']);

Route::get('subtracao/{num1}/{num2}', [OperationsController::class, 'sub']);

Route::get('multiplicacao/{num1}/{num2}', [OperationsController::class, 'multi']);

Route::get('divisao/{num1}/{num2}', [OperationsController::class, 'div']);

// Exercício 1 c)
Route::get('user/{name}/{lastName}/{age}/{rm}/{gender}/{address}', [UserController::class, 'index'])
->where(['age' => '[0-9]+']);

// Exercício 2
Route::get('produtos', [ProductsController::class, 'index']);
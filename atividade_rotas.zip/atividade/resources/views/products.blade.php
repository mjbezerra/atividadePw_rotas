<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="{{ asset('products.css') }}">
</head>
<body>
    <div class="products">
    <table>
        <tr>
        <th>Nome:</th>
        <th>Categoria:</th>
        <th>Descição:</th>
        <th>Preço:</th>
        </tr>
        @foreach($products as $products2) 
            <tr>
            @foreach($products2 as $products3=>$productsData) 
                <td> {{$productsData}} </td>
            @endforeach
            </tr>
        @endforeach
    </table>
    </div>
</body>
</html>
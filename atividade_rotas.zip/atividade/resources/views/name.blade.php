<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Name LastName</title>
    <link rel="stylesheet" href="{{ asset('name.css') }}">
</head>
<body>
    <div class="name">
        <h1>Olá, {{ $name }} {{ $lastName }}!</h1>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data</title>
    <link rel="stylesheet" href="{{ asset('user.css') }}">
</head>
<body>
    <fieldset>
        <legend><b>Dados do Usuário</b></legend>
            <p><b>Nome:</b> {{$name}}</p>
            <p><b>Sobrenome:</b> {{$lastName}}</p>
            <p><b>Idade:</b> {{$age}}</p>
            <p><b>RM:</b> {{$rm}}</p>
            <p><b>Gênero:</b> {{$gender}}</p>
            <p><b>Endereço:</b> {{$address}}</p>  
    </fieldset>
</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data</title>
    <link rel="stylesheet" href="<?php echo e(asset('user.css')); ?>">
</head>
<body>
    <fieldset>
        <legend><b>Dados do Usuário</b></legend>
            <p><b>Nome:</b> <?php echo e($name); ?></p>
            <p><b>Sobrenome:</b> <?php echo e($lastName); ?></p>
            <p><b>Idade:</b> <?php echo e($age); ?></p>
            <p><b>RM:</b> <?php echo e($rm); ?></p>
            <p><b>Gênero:</b> <?php echo e($gender); ?></p>
            <p><b>Endereço:</b> <?php echo e($address); ?></p>  
    </fieldset>
</body>
</html><?php /**PATH C:\etec\pw3\teste\resources\views/user.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Division by zero</title>
    <link rel="stylesheet" href="<?php echo e(asset('divisaozero.css')); ?>">
</head>
<body>
    <div>
        <h1>Escreva apenas números maiores que 0 (zero)!</h1>
    </div>
</body>
</html><?php /**PATH C:\etec\pw3\teste\resources\views/divisaozero.blade.php ENDPATH**/ ?>
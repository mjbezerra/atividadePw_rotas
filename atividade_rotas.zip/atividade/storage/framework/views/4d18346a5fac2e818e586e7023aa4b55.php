<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="<?php echo e(asset('products.css')); ?>">
</head>
<body>
    <div class="products">
    <table>
        <tr>
        <th>Nome:</th>
        <th>Categoria:</th>
        <th>Descição:</th>
        <th>Preço:</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
            <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products3=>$productsData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <td> <?php echo e($productsData); ?> </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
</body>
</html><?php /**PATH C:\etec\pw3\teste\resources\views/products.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

class OperationsController extends Controller
{
    public function sum($num1, $num2) {
        $result = $num1+$num2;
        return view('operations')
        ->with('num1', $num1)
        ->with('num2', $num2)
        ->with('result', $result);
    }

    public function sub($num1, $num2) {
        $result = $num1-$num2;
        return view('operations')
        ->with('num1', $num1)
        ->with('num2', $num2)
        ->with('result', $result);
    }

    public function multi($num1, $num2) {
        $result = $num1*$num2;
        return view('operations')
        ->with('num1', $num1)
        ->with('num2', $num2)
        ->with('result', $result);
    }

    public function div($num1, $num2) {
        if($num1>0 && $num2>0) {

            $result = $num1/$num2;

            return view('operations')
            ->with('num1', $num1)
            ->with('num2', $num2)
            ->with('result', $result);
        } else {
            return view('divisaozero');
        }
    }
}
<?php

namespace App\Http\Controllers;

class UserController extends Controller
{
    public function index($name, $lastName, $age, $rm, $gender, $address) {
        return view('user')
        ->with('name', $name)
        ->with('lastName', $lastName)
        ->with('age', $age)
        ->with('rm', $rm)
        ->with('gender', $gender)
        ->with('address', $address);
    }
}
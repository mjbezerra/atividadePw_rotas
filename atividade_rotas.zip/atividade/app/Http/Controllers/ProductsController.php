<?php

namespace App\Http\Controllers;

class ProductsController extends Controller
{
    public function index(){
        $products = [
            ['name'=>'A Culpa é das Estrelas','category'=>'Romance','description'=>'Capa Comum','price'=>'R$44,87'],
            ['name'=>'Garoto Encontra Garoto','category'=>'Romance','description'=>'Capa Comum','price'=>'R$19,90'],
            ['name'=>'Vermelho, Branco e Sangue Azul','category'=>'Romance','description'=>'Capa Comum','price'=>'R$35,91'],
            ['name'=>'Magisterium','category'=>'Fantasia','description'=>'Box: 5 livros, Capa Cumum','price'=>'R$60,00'],
            ['name'=>'As Crônicas de Nárnia','category'=>'Fantasia','description'=>'Box: 7 livros, Capa Dura','price'=>'R$276,90'],
            ['name'=>'Conan: O Bárbaro','category'=>'fantasia','description'=>'Box: 3 livros + Pôster','price'=>'R$183,92'],
            ['name'=>'O Auto da Compadecida','category'=>'Comédia','description'=>'Capa Comum','price'=>'R$46,12'],
            ['name'=>'Holy Cow: Uma Fábula Animal','category'=>'Comédia','description'=>'Capa Comum','price'=>'R$43,92'],
            ['name'=>'Cadê Você Bernadette?','category'=>'Comédia','description'=>'Capa Comum','price'=>'R$58,51'],
        ];
        return view('products')->with('products', $products);
    }
}
<?php

namespace App\Http\Controllers;

class NameController extends Controller
{
    public function index ($name, $lastName) {
        return view('name')->with('name',$name)->with('lastName', $lastName);
    }
}